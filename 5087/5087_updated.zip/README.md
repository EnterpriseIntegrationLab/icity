# City Data Model Ontologies
The continued development of the iCity TPSO ontologies as the _City Data Model_, a NWIP under ISO WG11. This is a temporary location for access and development until an official github project and domain name (and IRI) have been defined.

The associated NWIP proposals may be found at: https://github.com/EnterpriseIntegrationLab/City-Data-Model

Development will continue through the use of the [City Data Model Global Collaboratory](http://citydata.utoronto.ca "Collaboratory Homepage") as well as participation with the "Transportation Ontology Coorination Committee (TOCC)](https://github.com/w3c/tocc). 
