# To do list:

* ~~look into skos core import error~~
* resolve/replace schema:address references with iContact:Address
  * ~~BusinessEstablishment~~
  * ~~DwellingUnitPD~~
  * ~~Firm~~
  * ~~Organization~~
* ~~resolve: StopPoint (not) subclassOf NodePD~~
* ~~(re-)define Arc and subclasses: AtomicArc, Link~~
